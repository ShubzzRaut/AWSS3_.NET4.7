﻿using Amazon;
using Amazon.IdentityManagement;
using Amazon.IdentityManagement.Model;
using Amazon.Runtime;
using Amazon.S3;
using Amazon.S3.Transfer;
using System;
using System.IO;
using System.Net;
using System.Threading.Tasks;

namespace AWS_S3
{
    class Program
    {
        //private const string bucketName = "mydatabackup1";
        //private const string keyName = "testing1.zip"; // replace with the desired name for the file in S3
        //private const string filePath = @"E:\testing aws\testing1.zip"; // replace with the path to your ZIP file
        //private const int debugmode = 3;

        private static readonly RegionEndpoint region = RegionEndpoint.APSouth1;
        private static IAmazonS3 s3Client;
        static async Task Main(string[] args)
        {
            string drive = @"C:\OTHFILE\";
            string fileName = "LogCBack.txt";
            string logMessage = $"{DateTime.Now:dd-MM-yyyy hh:mm:ss}";
            string fullPath = Path.Combine(drive, fileName);
            
            File.AppendAllText(fullPath, "----------------------------------------------------------------------------------------------------" + Environment.NewLine);
            File.AppendAllText(fullPath,logMessage + Environment.NewLine);

            string bucketName = args[0];
            string keyName = args[1];
            string filePath = args[2];
            int debugmode = int.Parse(args[3]);

            if(debugmode >= 3)
            {
                File.AppendAllText(fullPath, "1) The parameter passed are as follows" + Environment.NewLine);
                File.AppendAllText(fullPath, "bucketName - " + bucketName + Environment.NewLine);
                File.AppendAllText(fullPath, "keyName - " + keyName + Environment.NewLine);
                File.AppendAllText(fullPath, "filePath - " + filePath + Environment.NewLine);
            }

            // Explicit AWS credentials
            
            var credentials = new BasicAWSCredentials("AKIA4MTWGSR4NXB7XHQ3", "AgRNuU08I8bQBHNJNZ3p6+z6FJ2uumy6OjgimupM");
            if (debugmode >= 3)
            {
                File.AppendAllText(fullPath, "2) Explicit AWS credentials INITIALIZED" + Environment.NewLine);

            }

            // Initialize IAM client with explicit credentials
            var iamClient = new AmazonIdentityManagementServiceClient(credentials, region);

            if (debugmode == 3)
            {
                File.AppendAllText(fullPath, "3) Initialize IAM client with explicit credentials" + Environment.NewLine );

            }


            // Check if the policy already exists
            var policyName = "MyS3Policy";
            if (debugmode == 3)
            {
                File.AppendAllText(fullPath, "4)NOW to Check if the policy already exists" + Environment.NewLine );

            }
            if (debugmode == 3)
            {
                File.AppendAllText(fullPath , "5)policy name - " + policyName + " already exists" + Environment.NewLine);

            }
            var policyArn = await GetPolicyArnAsync(iamClient, policyName);
            if (debugmode == 3)
            {
                File.AppendAllText(fullPath, "6)Started creating new policy" + Environment.NewLine);

            }
            if (policyArn == null)
            {
                // Create IAM Policy
                var policyJson = @"{
                    ""Version"": ""2012-10-17"",
                    ""Statement"": [
                        {
                            ""Effect"": ""Allow"",
                            ""Action"": [
                                ""s3:GetObject"",
                                ""s3:PutObject""
                            ],
                            ""Resource"": ""arn:aws:s3:::mydatabackup1/*""
                        }
                    ]
                }";

                var createPolicyRequest = new CreatePolicyRequest
                {
                    PolicyName = policyName,
                    PolicyDocument = policyJson,
                    Description = "Policy to allow S3 GetObject and PutObject actions."


                };
                
                try
                {
                    var createPolicyResponse = await iamClient.CreatePolicyAsync(createPolicyRequest);
                    policyArn = createPolicyResponse.Policy.Arn;
                   // Console.WriteLine($"Policy ARN: {policyArn}");
                    if (debugmode == 3)
                    {

                        File.AppendAllText(fullPath, $" 7) Policy ARN: {policyArn}" + Environment.NewLine);
                        File.AppendAllText(fullPath, "New Policy Name -" + policyName + Environment.NewLine);
                        File.AppendAllText(fullPath, "PolicyDocument -" + policyJson + Environment.NewLine);
                    }
                }
                catch (Exception ex)
                {
                    File.AppendAllText(fullPath, $"ERROR * Error while creating policy: {ex.Message}" + Environment.NewLine);
                    return;
                }
            }
            else
            {
                File.AppendAllText(fullPath, $" ERROR * Policy already exists. ARN: {policyArn}" + Environment.NewLine);
            }
            
            // Attach the Policy to a User or Role
            var userName = "MyNewIAMUser"; // Replace with your IAM user name

            var attachUserPolicyRequest = new AttachUserPolicyRequest
            {
                PolicyArn = policyArn,
                UserName = userName
            };
            try
            {
                await iamClient.AttachUserPolicyAsync(attachUserPolicyRequest);
               // Console.WriteLine($"Policy attached to user {userName}");
                if (debugmode == 3)
                {
                    File.AppendAllText(fullPath, "New Policy Created ");
                    File.AppendAllText(fullPath, $" 8) Policy attached to user {userName}" + Environment.NewLine);
                    
                }

                // Initialize S3 client with explicit credentials
                var s3Client = new AmazonS3Client(credentials, region);
                if (debugmode == 3)
                {
                    File.AppendAllText(fullPath, "9) Now Initialize S3 client with explicit credentials" + Environment.NewLine);

                }
                await UploadFileAsync(s3Client , bucketName , keyName, filePath , debugmode, fullPath);
            }
            catch (Exception ex)
            {
                File.AppendAllText(fullPath, $"4) * Error attaching policy: {ex.Message}");
            }
           Console.ReadLine();
        }

        private static async Task<string> GetPolicyArnAsync(IAmazonIdentityManagementService iamClient, string policyName)
        {
            try
            {
                var listPoliciesRequest = new ListPoliciesRequest
                {
                    Scope = "All" // This includes policies that are managed by AWS and custom policies
                };

                var listPoliciesResponse = await iamClient.ListPoliciesAsync(listPoliciesRequest);

                foreach (var policy in listPoliciesResponse.Policies)
                {
                    if (policy.PolicyName == policyName)
                    {
                        return policy.Arn;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"ERROR : Error listing policies: {ex.Message}");
            }

            return null;
            
        }


        private static async Task UploadFileAsync(IAmazonS3 s3Client, string bucketName , string keyname , string filePath , int debugmode , string fullPath)
        {
            if (debugmode == 3)
            {
                File.AppendAllText(fullPath, "10) In a UploadFileAsync method for upload in AWS S3" + Environment.NewLine);

            }
            try
            {
                var fileTransferUtility = new TransferUtility(s3Client);

                // Upload the file
                await fileTransferUtility.UploadAsync(filePath,bucketName, keyname );
                // Console.WriteLine($"File Succesfully uploaded to {bucketName}/{keyname}");
                if (debugmode == 3)
                {
                    File.AppendAllText(fullPath, $" 11) File Succesfully uploaded to AWS S3 of {bucketName}/{keyname}" + Environment.NewLine);

                }
            }
            catch (AmazonS3Exception e)
            {
                File.AppendAllText(fullPath, $" ERROR: Error encountered on server. Message: '{e.Message}' when writing an object" + Environment.NewLine);
            }
            catch (Exception e)
            {
                File.AppendAllText(fullPath, $" ERROR: Unknown error encountered on server. Message: '{e.Message}' when writing an object" + Environment.NewLine);
            }
            Console.ReadLine();
        }
    }
}
